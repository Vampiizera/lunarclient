import { z } from 'zod';
import { insertModpackSchema, insertNewsSchema, insertLaunchOptionsSchema, modpacks, news, launchOptions } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  modpacks: {
    list: {
      method: 'GET' as const,
      path: '/api/modpacks',
      responses: {
        200: z.array(z.custom<typeof modpacks.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/modpacks',
      input: insertModpackSchema,
      responses: {
        201: z.custom<typeof modpacks.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/modpacks/:id',
      input: insertModpackSchema.partial(),
      responses: {
        200: z.custom<typeof modpacks.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/modpacks/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  news: {
    list: {
      method: 'GET' as const,
      path: '/api/news',
      responses: {
        200: z.array(z.custom<typeof news.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/news',
      input: insertNewsSchema,
      responses: {
        201: z.custom<typeof news.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  launchOptions: {
    get: {
      method: 'GET' as const,
      path: '/api/launch-options',
      responses: {
        200: z.custom<typeof launchOptions.$inferSelect>(),
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/launch-options',
      input: insertLaunchOptionsSchema,
      responses: {
        200: z.custom<typeof launchOptions.$inferSelect>(),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
