import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { insertModpackSchema, type InsertModpack, type Modpack } from "@shared/schema";
import { useCreateModpack, useUpdateModpack } from "@/hooks/use-modpacks";
import { useState, useEffect } from "react";
import { Loader2, Plus } from "lucide-react";

interface Props {
  modpack?: Modpack; // If provided, we are in edit mode
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateModpackDialog({ modpack, open, onOpenChange }: Props) {
  const createMutation = useCreateModpack();
  const updateMutation = useUpdateModpack();
  const isEditing = !!modpack;

  const form = useForm<InsertModpack>({
    resolver: zodResolver(insertModpackSchema),
    defaultValues: {
      name: "",
      description: "",
      version: "1.8.9",
      iconUrl: "",
      bannerUrl: "",
      category: "PvP",
      isFavorite: false,
      downloads: 0,
    },
  });

  useEffect(() => {
    if (modpack) {
      form.reset({
        name: modpack.name,
        description: modpack.description,
        version: modpack.version,
        iconUrl: modpack.iconUrl,
        bannerUrl: modpack.bannerUrl || "",
        category: modpack.category || "PvP",
        isFavorite: modpack.isFavorite || false,
        downloads: modpack.downloads || 0,
      });
    } else {
      form.reset({
        name: "",
        description: "",
        version: "1.8.9",
        iconUrl: "",
        bannerUrl: "",
        category: "PvP",
        isFavorite: false,
        downloads: 0,
      });
    }
  }, [modpack, form]);

  const onSubmit = async (data: InsertModpack) => {
    try {
      if (isEditing && modpack) {
        await updateMutation.mutateAsync({ id: modpack.id, ...data });
      } else {
        await createMutation.mutateAsync(data);
      }
      onOpenChange(false);
      if (!isEditing) form.reset();
    } catch (e) {
      console.error(e);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {isEditing ? "Edit Modpack" : "Create New Modpack"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Name</label>
            <input
              {...form.register("name")}
              className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary/50 transition-colors"
              placeholder="e.g. Lunar PvP"
            />
            {form.formState.errors.name && (
              <p className="text-xs text-destructive">{form.formState.errors.name.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Version</label>
              <select
                {...form.register("version")}
                className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary/50"
              >
                <option value="1.8.9">1.8.9</option>
                <option value="1.7.10">1.7.10</option>
                <option value="1.19.4">1.19.4</option>
                <option value="1.20.4">1.20.4</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Category</label>
              <select
                {...form.register("category")}
                className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary/50"
              >
                <option value="PvP">PvP</option>
                <option value="Survival">Survival</option>
                <option value="Creative">Creative</option>
                <option value="Utility">Utility</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Description</label>
            <textarea
              {...form.register("description")}
              className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary/50 min-h-[80px]"
              placeholder="What makes this pack special?"
            />
            {form.formState.errors.description && (
              <p className="text-xs text-destructive">{form.formState.errors.description.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Icon URL (Unsplash)</label>
            <input
              {...form.register("iconUrl")}
              className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary/50"
              placeholder="https://images.unsplash.com/..."
            />
            {form.formState.errors.iconUrl && (
              <p className="text-xs text-destructive">{form.formState.errors.iconUrl.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isPending}
            className="w-full py-2.5 rounded-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2 mt-2"
          >
            {isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {isEditing ? "Save Changes" : "Create Modpack"}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
