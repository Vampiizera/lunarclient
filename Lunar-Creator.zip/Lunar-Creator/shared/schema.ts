import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const modpacks = pgTable("modpacks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  version: text("version").notNull(),
  iconUrl: text("icon_url").notNull(),
  bannerUrl: text("banner_url"),
  isFavorite: boolean("is_favorite").default(false),
  downloads: integer("downloads").default(0),
  category: text("category").default("PvP"),
});

export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url").notNull(),
  author: text("author").default("Lunar Team"),
  date: timestamp("date").defaultNow(),
});

export const launchOptions = pgTable("launch_options", {
  id: serial("id").primaryKey(),
  ramMin: integer("ram_min").default(2048),
  ramMax: integer("ram_max").default(4096),
  width: integer("width").default(1280),
  height: integer("height").default(720),
  javaPath: text("java_path").default("javaw.exe"),
  fullscreen: boolean("fullscreen").default(false),
});

export const insertModpackSchema = createInsertSchema(modpacks).omit({ id: true });
export const insertNewsSchema = createInsertSchema(news).omit({ id: true, date: true });
export const insertLaunchOptionsSchema = createInsertSchema(launchOptions).omit({ id: true });

export type Modpack = typeof modpacks.$inferSelect;
export type InsertModpack = z.infer<typeof insertModpackSchema>;
export type News = typeof news.$inferSelect;
export type InsertNews = z.infer<typeof insertNewsSchema>;
export type LaunchOptions = typeof launchOptions.$inferSelect;
export type InsertLaunchOptions = z.infer<typeof insertLaunchOptionsSchema>;
