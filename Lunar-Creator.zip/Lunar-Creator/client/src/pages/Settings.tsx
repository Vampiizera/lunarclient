import { useLaunchOptions, useUpdateLaunchOptions } from "@/hooks/use-launch-options";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertLaunchOptionsSchema, type InsertLaunchOptions } from "@shared/schema";
import { useEffect } from "react";
import { Save, Monitor, Cpu, Folder, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Settings() {
  const { data: options, isLoading } = useLaunchOptions();
  const updateMutation = useUpdateLaunchOptions();
  const { toast } = useToast();

  const form = useForm<InsertLaunchOptions>({
    resolver: zodResolver(insertLaunchOptionsSchema),
    defaultValues: {
      ramMin: 2048,
      ramMax: 4096,
      width: 1280,
      height: 720,
      javaPath: "javaw.exe",
      fullscreen: false,
    },
  });

  useEffect(() => {
    if (options) {
      form.reset(options);
    }
  }, [options, form]);

  const onSubmit = async (data: InsertLaunchOptions) => {
    try {
      await updateMutation.mutateAsync(data);
      toast({
        title: "Settings Saved",
        description: "Your launch configuration has been updated.",
      });
    } catch (e) {
      toast({
        title: "Error",
        description: "Failed to save settings.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) return null;

  return (
    <div className="max-w-3xl">
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold tracking-tight mb-2">Launcher Settings</h1>
        <p className="text-muted-foreground">Configure how your game launches and performs.</p>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        {/* Memory Allocation */}
        <section className="bg-card border border-white/5 rounded-2xl p-6 lg:p-8 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-primary/10 rounded-lg text-primary"><Cpu className="w-5 h-5" /></div>
            <h2 className="text-xl font-bold">Memory Allocation</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <label className="text-sm font-medium flex justify-between">
                <span>Minimum RAM (MB)</span>
                <span className="text-primary font-mono">{form.watch("ramMin")} MB</span>
              </label>
              <input
                type="range"
                min="1024"
                max="16384"
                step="512"
                {...form.register("ramMin", { valueAsNumber: true })}
                className="w-full accent-primary h-2 bg-black/40 rounded-lg appearance-none cursor-pointer"
              />
            </div>
            
            <div className="space-y-4">
              <label className="text-sm font-medium flex justify-between">
                <span>Maximum RAM (MB)</span>
                <span className="text-primary font-mono">{form.watch("ramMax")} MB</span>
              </label>
              <input
                type="range"
                min="1024"
                max="16384"
                step="512"
                {...form.register("ramMax", { valueAsNumber: true })}
                className="w-full accent-primary h-2 bg-black/40 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>
        </section>

        {/* Display Settings */}
        <section className="bg-card border border-white/5 rounded-2xl p-6 lg:p-8 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400"><Monitor className="w-5 h-5" /></div>
            <h2 className="text-xl font-bold">Display</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Resolution Width</label>
              <input
                type="number"
                {...form.register("width", { valueAsNumber: true })}
                className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 focus:border-primary/50 focus:outline-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Resolution Height</label>
              <input
                type="number"
                {...form.register("height", { valueAsNumber: true })}
                className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 focus:border-primary/50 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-black/20 rounded-xl border border-white/5">
            <div>
              <div className="font-medium">Fullscreen Mode</div>
              <div className="text-sm text-muted-foreground">Launch the game in fullscreen</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                {...form.register("fullscreen")}
                className="sr-only peer" 
              />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
            </label>
          </div>
        </section>

        {/* Java Settings */}
        <section className="bg-card border border-white/5 rounded-2xl p-6 lg:p-8 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-orange-500/10 rounded-lg text-orange-400"><Folder className="w-5 h-5" /></div>
            <h2 className="text-xl font-bold">Java Configuration</h2>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Java Executable Path</label>
            <div className="flex gap-2">
              <input
                {...form.register("javaPath")}
                className="flex-1 bg-black/20 border border-white/10 rounded-lg px-4 py-3 focus:border-primary/50 focus:outline-none font-mono text-sm"
              />
              <button type="button" className="px-4 py-2 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10">
                Browse
              </button>
            </div>
          </div>
        </section>

        <div className="flex items-center gap-4 pt-4">
          <button
            type="submit"
            disabled={updateMutation.isPending}
            className="launcher-btn px-8 py-3 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 flex items-center gap-2 shadow-lg shadow-primary/20"
          >
            {updateMutation.isPending ? <RotateCcw className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            Save Configuration
          </button>
        </div>
      </form>
    </div>
  );
}
