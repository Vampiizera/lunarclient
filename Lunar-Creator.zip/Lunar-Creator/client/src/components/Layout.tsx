import { Link, useLocation } from "wouter";
import { Gamepad2, Newspaper, Settings, Edit3, X, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { useEditMode } from "./EditModeContext";
import { motion } from "framer-motion";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { isEditMode, toggleEditMode } = useEditMode();

  const navItems = [
    { href: "/", label: "Home", icon: Newspaper },
    { href: "/mods", label: "Mods", icon: Gamepad2 },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex overflow-hidden font-sans selection:bg-primary/30">
      {/* Sidebar */}
      <aside className="w-20 lg:w-64 flex-shrink-0 bg-card border-r border-white/5 flex flex-col items-center lg:items-stretch py-6 z-20">
        {/* Logo */}
        <div className="px-4 mb-8 flex items-center justify-center lg:justify-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/20">
            <Zap className="text-black fill-black w-6 h-6" />
          </div>
          <span className="hidden lg:block font-bold text-xl tracking-tight">
            VAMPII<span className="text-primary">LAUNCHER</span>
          </span>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "group flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 cursor-pointer",
                  isActive
                    ? "bg-primary/10 text-primary font-semibold shadow-[0_0_20px_-5px_rgba(53,208,127,0.3)]"
                    : "text-muted-foreground hover:bg-white/5 hover:text-white",
                )}
              >
                <item.icon
                  className={cn(
                    "w-6 h-6 transition-transform group-hover:scale-110",
                    isActive && "fill-current",
                  )}
                />
                <span className="hidden lg:block">{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="active-pill"
                    className="absolute left-0 w-1 h-8 bg-primary rounded-r-full lg:hidden"
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Edit Mode Toggle */}
        <div className="px-3 mt-auto">
          <button
            onClick={toggleEditMode}
            className={cn(
              "w-full flex items-center justify-center lg:justify-start gap-3 px-3 py-3 rounded-xl transition-all duration-200 border",
              isEditMode
                ? "bg-amber-500/10 border-amber-500/50 text-amber-500"
                : "bg-transparent border-transparent text-muted-foreground hover:bg-white/5",
            )}
          >
            {isEditMode ? (
              <X className="w-5 h-5" />
            ) : (
              <Edit3 className="w-5 h-5" />
            )}
            <span className="hidden lg:block font-medium">
              {isEditMode ? "Exit Edit Mode" : "Edit Launcher"}
            </span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 relative overflow-hidden flex flex-col">
        {/* Top Bar Background Gradient */}
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />

        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-10 relative z-10 scroll-smooth">
          <div className="max-w-7xl mx-auto">{children}</div>
        </div>
      </main>
    </div>
  );
}
