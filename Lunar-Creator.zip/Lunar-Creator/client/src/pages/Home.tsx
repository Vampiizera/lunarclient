import { useNews } from "@/hooks/use-news";
import { useEditMode } from "@/components/EditModeContext";
import { CreateNewsDialog } from "@/components/CreateNewsDialog";
import { useState } from "react";
import { Plus, Clock, User, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

export default function Home() {
  const { data: news, isLoading } = useNews();
  const { isEditMode } = useEditMode();
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Use the first item as featured if available
  const featured = news && news.length > 0 ? news[0] : null;
  const gridItems = news ? news.slice(1) : [];

  return (
    <div className="space-y-8 pb-20">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-extrabold tracking-tight">
          Ultimas Noticias
        </h1>
        {isEditMode && (
          <button
            onClick={() => setIsCreateOpen(true)}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
          >
            <Plus className="w-4 h-4" /> Post Update
          </button>
        )}
      </div>

      {featured ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative group rounded-3xl overflow-hidden aspect-video lg:aspect-[2.5/1] shadow-2xl border border-white/10 cursor-pointer"
        >
          <img
            src={featured.imageUrl}
            alt={featured.title}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

          <div className="absolute bottom-0 left-0 p-8 lg:p-12 max-w-2xl">
            <div className="flex items-center gap-4 text-sm text-primary font-medium mb-3">
              <span className="flex items-center gap-1.5 bg-black/50 backdrop-blur px-3 py-1 rounded-full border border-white/10">
                <Clock className="w-3.5 h-3.5" />
                {featured.date &&
                  format(new Date(featured.date), "MMM d, yyyy")}
              </span>
              <span className="flex items-center gap-1.5 bg-black/50 backdrop-blur px-3 py-1 rounded-full border border-white/10">
                <User className="w-3.5 h-3.5" />
                {featured.author}
              </span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4 leading-tight group-hover:text-primary transition-colors">
              {featured.title}
            </h2>
            <p className="text-gray-300 line-clamp-2 text-lg mb-6">
              {featured.content}
            </p>
            <div className="flex items-center gap-2 text-primary font-bold tracking-wide uppercase text-sm group-hover:translate-x-1 transition-transform">
              Read Article <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </motion.div>
      ) : (
        <div className="p-12 text-center text-muted-foreground bg-card/30 rounded-3xl border border-white/5 border-dashed">
          No news updates yet.
        </div>
      )}

      {/* Grid for older news */}
      {gridItems.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {gridItems.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group bg-card border border-white/5 rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 flex flex-col h-full"
            >
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-60" />
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                  <span>
                    {item.date && format(new Date(item.date), "MMM d")}
                  </span>
                  <span>{item.author}</span>
                </div>
                <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors line-clamp-2">
                  {item.title}
                </h3>
                <p className="text-sm text-gray-400 line-clamp-3 mb-4 flex-1">
                  {item.content}
                </p>
                <div className="text-xs font-bold uppercase tracking-wider text-primary">
                  Read more
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <CreateNewsDialog open={isCreateOpen} onOpenChange={setIsCreateOpen} />
    </div>
  );
}
