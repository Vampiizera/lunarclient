import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Modpacks
  app.get(api.modpacks.list.path, async (req, res) => {
    const modpacks = await storage.getModpacks();
    res.json(modpacks);
  });

  app.post(api.modpacks.create.path, async (req, res) => {
    try {
      const input = api.modpacks.create.input.parse(req.body);
      const modpack = await storage.createModpack(input);
      res.status(201).json(modpack);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.put(api.modpacks.update.path, async (req, res) => {
    try {
      const input = api.modpacks.update.input.parse(req.body);
      const modpack = await storage.updateModpack(Number(req.params.id), input);
      if (!modpack) {
        return res.status(404).json({ message: "Modpack not found" });
      }
      res.json(modpack);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.modpacks.delete.path, async (req, res) => {
    await storage.deleteModpack(Number(req.params.id));
    res.status(204).send();
  });

  // News
  app.get(api.news.list.path, async (req, res) => {
    const news = await storage.getNews();
    res.json(news);
  });

  app.post(api.news.create.path, async (req, res) => {
    try {
      const input = api.news.create.input.parse(req.body);
      const newItem = await storage.createNews(input);
      res.status(201).json(newItem);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Launch Options
  app.get(api.launchOptions.get.path, async (req, res) => {
    const options = await storage.getLaunchOptions();
    res.json(options);
  });

  app.post(api.launchOptions.update.path, async (req, res) => {
    try {
      const input = api.launchOptions.update.input.parse(req.body);
      const options = await storage.updateLaunchOptions(input);
      res.json(options);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Initial Seed
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingModpacks = await storage.getModpacks();
  if (existingModpacks.length === 0) {
    await storage.createModpack({
      name: "Lunar Client PvP",
      description: "The ultimate PvP experience with boosted FPS and custom mods.",
      version: "1.8.9",
      iconUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f",
      bannerUrl: "https://images.unsplash.com/photo-1627856014759-085229246708",
      category: "PvP",
      isFavorite: true,
      downloads: 1500000,
    });
    await storage.createModpack({
      name: "Survival Enhanced",
      description: "A vanilla+ experience with quality of life improvements.",
      version: "1.20.4",
      iconUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e",
      bannerUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420",
      category: "Survival",
      isFavorite: false,
      downloads: 50000,
    });
    await storage.createModpack({
      name: "Skyblock Addons",
      description: "Essential mods for Hypixel Skyblock players.",
      version: "1.8.9",
      iconUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f",
      bannerUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f",
      category: "Skyblock",
      isFavorite: false,
      downloads: 800000,
    });
  }

  const existingNews = await storage.getNews();
  if (existingNews.length === 0) {
    await storage.createNews({
      title: "Lunar Client 2.0 Update",
      content: "We've completely overhauled the UI and improved performance across all versions.",
      imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e",
      author: "Lunar Team",
    });
    await storage.createNews({
      title: "New Cosmetics Available",
      content: "Check out the store for new capes, wings, and bandanas!",
      imageUrl: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f",
      author: "Marketplace Team",
    });
  }
}
