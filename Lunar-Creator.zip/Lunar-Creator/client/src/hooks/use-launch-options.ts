import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertLaunchOptions } from "@shared/routes";

export function useLaunchOptions() {
  return useQuery({
    queryKey: [api.launchOptions.get.path],
    queryFn: async () => {
      const res = await fetch(api.launchOptions.get.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch launch options");
      return api.launchOptions.get.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateLaunchOptions() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertLaunchOptions) => {
      const validated = api.launchOptions.update.input.parse(data);
      const res = await fetch(api.launchOptions.update.path, {
        method: api.launchOptions.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update launch options");
      return api.launchOptions.update.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.launchOptions.get.path] }),
  });
}
