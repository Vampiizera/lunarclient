import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertModpack } from "@shared/routes";

export function useModpacks() {
  return useQuery({
    queryKey: [api.modpacks.list.path],
    queryFn: async () => {
      const res = await fetch(api.modpacks.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch modpacks");
      return api.modpacks.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateModpack() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertModpack) => {
      const validated = api.modpacks.create.input.parse(data);
      const res = await fetch(api.modpacks.create.path, {
        method: api.modpacks.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create modpack");
      return api.modpacks.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.modpacks.list.path] }),
  });
}

export function useUpdateModpack() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertModpack>) => {
      const validated = api.modpacks.update.input.parse(updates);
      const url = buildUrl(api.modpacks.update.path, { id });
      const res = await fetch(url, {
        method: api.modpacks.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update modpack");
      return api.modpacks.update.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.modpacks.list.path] }),
  });
}

export function useDeleteModpack() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.modpacks.delete.path, { id });
      const res = await fetch(url, {
        method: api.modpacks.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete modpack");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.modpacks.list.path] }),
  });
}
