import { useModpacks, useDeleteModpack } from "@/hooks/use-modpacks";
import { useEditMode } from "@/components/EditModeContext";
import { CreateModpackDialog } from "@/components/CreateModpackDialog";
import { useState } from "react";
import { Plus, Play, Trash2, Edit2, Heart, Download } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Modpack } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Mods() {
  const { data: modpacks, isLoading } = useModpacks();
  const deleteMutation = useDeleteModpack();
  const { isEditMode } = useEditMode();
  const { toast } = useToast();
  
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingModpack, setEditingModpack] = useState<Modpack | undefined>(undefined);

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to remove this modpack?")) {
      await deleteMutation.mutateAsync(id);
      toast({
        title: "Modpack Removed",
        description: "The modpack has been successfully deleted.",
      });
    }
  };

  const handleEdit = (e: React.MouseEvent, modpack: Modpack) => {
    e.stopPropagation();
    setEditingModpack(modpack);
    setIsCreateOpen(true);
  };

  const handleLaunch = (e: React.MouseEvent, name: string) => {
    e.stopPropagation();
    toast({
      title: "Launching " + name,
      description: "Preparing game files...",
      duration: 3000,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">My Modpacks</h1>
          <p className="text-muted-foreground mt-1">Select a version to play</p>
        </div>
        {isEditMode && (
          <button
            onClick={() => {
              setEditingModpack(undefined);
              setIsCreateOpen(true);
            }}
            className="launcher-btn bg-primary text-primary-foreground px-6 py-2.5 rounded-xl shadow-lg shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-0.5 flex items-center gap-2"
          >
            <Plus className="w-5 h-5" /> Add Version
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <AnimatePresence>
          {modpacks?.map((pack, i) => (
            <motion.div
              key={pack.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: i * 0.05 }}
              className="launcher-card group relative p-5 flex flex-col h-full"
            >
              {isEditMode && (
                <div className="absolute top-4 right-4 flex gap-2 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => handleEdit(e, pack)}
                    className="p-2 bg-black/60 backdrop-blur rounded-lg hover:bg-white/20 text-white transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => handleDelete(e, pack.id)}
                    className="p-2 bg-black/60 backdrop-blur rounded-lg hover:bg-destructive/80 text-destructive-foreground transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}

              <div className="flex items-start gap-4 mb-4">
                <div className="w-16 h-16 rounded-2xl overflow-hidden bg-black/40 flex-shrink-0 border border-white/5">
                  <img 
                    src={pack.iconUrl || `https://ui-avatars.com/api/?name=${pack.name}&background=35D07F&color=fff`} 
                    alt={pack.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold px-2 py-0.5 rounded bg-white/5 text-muted-foreground border border-white/5">
                      {pack.version}
                    </span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded bg-primary/10 text-primary border border-primary/10">
                      {pack.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold truncate">{pack.name}</h3>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                    <span className="flex items-center gap-1"><Download className="w-3 h-3" /> {pack.downloads?.toLocaleString()}</span>
                    {pack.isFavorite && <Heart className="w-3 h-3 fill-rose-500 text-rose-500" />}
                  </div>
                </div>
              </div>

              <p className="text-sm text-gray-400 mb-6 flex-1 line-clamp-2">
                {pack.description}
              </p>

              <button 
                onClick={(e) => handleLaunch(e, pack.name)}
                className="launcher-btn w-full bg-gradient-to-r from-primary to-emerald-500 text-black py-3.5 rounded-xl shadow-lg shadow-emerald-500/20 group-hover:shadow-emerald-500/40 hover:-translate-y-0.5 flex items-center justify-center gap-2 group-hover:from-emerald-400 group-hover:to-primary"
              >
                <Play className="w-5 h-5 fill-black" />
                Launch
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {modpacks?.length === 0 && (
          <div className="col-span-full py-20 text-center text-muted-foreground">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/5 mb-4">
              <Gamepad2 className="w-8 h-8 opacity-50" />
            </div>
            <h3 className="text-lg font-medium text-white mb-2">No Modpacks Installed</h3>
            <p>Click "Edit Launcher" to add your first version.</p>
          </div>
        )}
      </div>

      <CreateModpackDialog 
        open={isCreateOpen} 
        onOpenChange={setIsCreateOpen} 
        modpack={editingModpack} 
      />
    </div>
  );
}

function Gamepad2(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="6" x2="10" y1="12" y2="12" />
      <line x1="8" x2="8" y1="10" y2="14" />
      <line x1="15" x2="15.01" y1="13" y2="13" />
      <line x1="18" x2="18.01" y1="11" y2="11" />
      <rect width="20" height="12" x="2" y="6" rx="2" />
    </svg>
  );
}
