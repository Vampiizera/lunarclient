## Packages
(none needed)

## Notes
Using base stack packages: framer-motion, lucide-react, react-hook-form, zod, tanstack-query.
Images will use Unsplash URLs as placeholders where dynamic uploads aren't implemented.
