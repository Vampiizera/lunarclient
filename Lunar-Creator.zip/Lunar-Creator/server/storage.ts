import { 
  modpacks, news, launchOptions,
  type Modpack, type InsertModpack,
  type News, type InsertNews,
  type LaunchOptions, type InsertLaunchOptions
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Modpacks
  getModpacks(): Promise<Modpack[]>;
  createModpack(modpack: InsertModpack): Promise<Modpack>;
  updateModpack(id: number, modpack: Partial<InsertModpack>): Promise<Modpack | undefined>;
  deleteModpack(id: number): Promise<void>;

  // News
  getNews(): Promise<News[]>;
  createNews(newsItem: InsertNews): Promise<News>;

  // Launch Options
  getLaunchOptions(): Promise<LaunchOptions>;
  updateLaunchOptions(options: InsertLaunchOptions): Promise<LaunchOptions>;
}

export class DatabaseStorage implements IStorage {
  async getModpacks(): Promise<Modpack[]> {
    return await db.select().from(modpacks);
  }

  async createModpack(insertModpack: InsertModpack): Promise<Modpack> {
    const [modpack] = await db.insert(modpacks).values(insertModpack).returning();
    return modpack;
  }

  async updateModpack(id: number, updates: Partial<InsertModpack>): Promise<Modpack | undefined> {
    const [updated] = await db
      .update(modpacks)
      .set(updates)
      .where(eq(modpacks.id, id))
      .returning();
    return updated;
  }

  async deleteModpack(id: number): Promise<void> {
    await db.delete(modpacks).where(eq(modpacks.id, id));
  }

  async getNews(): Promise<News[]> {
    return await db.select().from(news).orderBy(news.date);
  }

  async createNews(insertNews: InsertNews): Promise<News> {
    const [newItem] = await db.insert(news).values(insertNews).returning();
    return newItem;
  }

  async getLaunchOptions(): Promise<LaunchOptions> {
    const [options] = await db.select().from(launchOptions).limit(1);
    if (!options) {
      // Create default if not exists
      const [newOptions] = await db.insert(launchOptions).values({}).returning();
      return newOptions;
    }
    return options;
  }

  async updateLaunchOptions(updates: InsertLaunchOptions): Promise<LaunchOptions> {
    const existing = await this.getLaunchOptions();
    const [updated] = await db
      .update(launchOptions)
      .set(updates)
      .where(eq(launchOptions.id, existing.id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
